import express from "express";
import {
  getInitialData,
  saveAdminUsers,
  saveCategories,
  saveOrders,
  saveProducts,
  saveMessages,
  saveSubscribers,
  createId,
} from "./database.js";
import { hashPassword, verifyPassword, createToken, verifyToken, revokeToken } from "./auth.js";

const router = express.Router();

let statePromise;

async function getState() {
  if (!statePromise) {
    statePromise = bootstrapState();
  }
  return statePromise;
}

async function bootstrapState() {
  const initial = await getInitialData();
  if (!initial.adminUsers.length) {
    const defaultAdmin = {
      id: createId(),
      email: "assaimartofficial@gmail.com",
      passwordHash: hashPassword("AssaiMart123#"),
      name: "Administrator",
    };
    initial.adminUsers.push(defaultAdmin);
    await saveAdminUsers(initial.adminUsers);
  }
  if (!initial.categories.length) {
    initial.categories = [
      { id: createId(), name: "Premium Perfumes", slug: "premium", tier: "premium" },
      { id: createId(), name: "Medium Range Perfumes", slug: "medium", tier: "medium" },
      { id: createId(), name: "Basic / Budget Perfumes", slug: "basic", tier: "basic" },
      { id: createId(), name: "Men", slug: "men", tier: "segment-men" },
      { id: createId(), name: "Women", slug: "women", tier: "segment-women" },
      { id: createId(), name: "Unisex", slug: "unisex", tier: "segment-unisex" },
    ];
    await saveCategories(initial.categories);
  }
  return initial;
}

function withOrderItemImages(order, products) {
  if (!order || !Array.isArray(order.items)) {
    return order;
  }
  return {
    ...order,
    items: order.items.map((item) => {
      const product = products.find((p) => p.id === item.productId);
      const imageUrl = product && (product.imageUrl || product.image);
      if (!imageUrl) {
        return item;
      }
      return {
        ...item,
        imageUrl,
      };
    }),
  };
}

// Middleware to check for admin authentication
async function requireAdmin(req, res, next) {
  const header = req.headers["authorization"];
  if (!header) return res.status(401).json({ error: "Unauthorized" });
  
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) return res.status(401).json({ error: "Unauthorized" });

  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ error: "Unauthorized" });

  const state = await getState();
  const admin = state.adminUsers.find((u) => u.id === payload.adminId);
  if (!admin) return res.status(401).json({ error: "Unauthorized" });

  req.adminContext = { state, admin, token };
  next();
}

// Public Routes

router.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

router.post("/admin/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const state = await getState();
    const admin = state.adminUsers.find((u) => u.email === email);
    if (!admin || !verifyPassword(password, admin.passwordHash)) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = createToken(admin.id);
    res.json({
      token,
      admin: { id: admin.id, email: admin.email, name: admin.name },
    });
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: "Invalid request body" });
  }
});

router.post("/admin/logout", (req, res) => {
  const header = req.headers["authorization"];
  if (header) {
    const [scheme, token] = header.split(" ");
    if (scheme === "Bearer" && token) {
      revokeToken(token);
    }
  }
  res.json({ success: true });
});

router.post("/admin/reset-password", async (req, res) => {
  try {
    const state = await getState();
    const { password } = req.body;
    
    if (!password || typeof password !== "string" || password.length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters" });
    }

    let index = state.adminUsers.findIndex((u) => u.email === "assaimartofficial@gmail.com");
    if (index === -1 && state.adminUsers.length > 0) {
      index = 0;
    }

    if (index === -1) {
      return res.status(404).json({ error: "Admin user not found" });
    }

    state.adminUsers[index].passwordHash = hashPassword(password);
    await saveAdminUsers(state.adminUsers);
    
    res.json({ success: true });
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: "Invalid request body" });
  }
});

router.get("/categories", async (req, res) => {
  const state = await getState();
  res.json(state.categories);
});

router.post("/contact", async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !subject || !message) {
      return res.status(400).json({ error: "Missing contact information" });
    }
    const state = await getState();
    if (!Array.isArray(state.messages)) {
      state.messages = [];
    }
    const entry = {
      id: createId(),
      name,
      email,
      subject,
      message,
      createdAt: new Date().toISOString(),
      read: false,
    };
    state.messages.push(entry);
    await saveMessages(state.messages);
    res.status(201).json({ success: true });
  } catch {
    res.status(400).json({ error: "Invalid request body" });
  }
});

router.post("/newsletter/subscribe", async (req, res) => {
  try {
    const body = req.body;
    const email = body && typeof body.email === "string" ? body.email.trim() : "";
    if (!email) {
      return res.status(400).json({ error: "Email is required" });
    }
    const state = await getState();
    if (!Array.isArray(state.subscribers)) {
      state.subscribers = [];
    }
    const exists = state.subscribers.some(
      (s) => s.email && s.email.toLowerCase() === email.toLowerCase()
    );
    if (!exists) {
      state.subscribers.push({
        id: createId(),
        email,
        createdAt: new Date().toISOString(),
      });
      await saveSubscribers(state.subscribers);
    }
    res.json({ success: true });
  } catch {
    res.status(400).json({ error: "Invalid request body" });
  }
});

router.get("/products", async (req, res) => {
  const state = await getState();
  let items = [...state.products];
  const query = req.query;

  if (query.category) {
    items = items.filter((p) => p.categorySlug === query.category);
  }
  if (query.segment) {
    items = items.filter((p) => p.segment === query.segment);
  }
  if (query.tier) {
    items = items.filter((p) => p.tier === query.tier);
  }
  if (query.productType) {
    items = items.filter((p) => (p.productType || "Perfume") === query.productType);
  }
  if (query.featured) {
    items = items.filter((p) => p.featuredHome);
  }
  if (query.q) {
    const term = String(query.q).toLowerCase();
    items = items.filter((p) => p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term));
  }
  res.json(items);
});

router.get("/products/:id", async (req, res) => {
  const { id } = req.params;
  const state = await getState();
  const product = state.products.find((p) => p.id === id);
  if (!product) {
    return res.status(404).json({ error: "Not found" });
  }
  res.json(product);
});

router.post("/checkout", async (req, res) => {
  try {
    const { items, customer } = req.body;
    if (!items || !Array.isArray(items) || !customer || !customer.name || !customer.phone || !customer.address) {
      return res.status(400).json({ error: "Missing order information" });
    }
    const state = await getState();
    const order = {
      id: createId(),
      items,
      customer,
      status: "processing",
      createdAt: new Date().toISOString(),
    };
    state.orders.push(order);
    await saveOrders(state.orders);
    res.status(201).json({ orderId: order.id });
  } catch {
    res.status(400).json({ error: "Invalid request body" });
  }
});

router.get("/orders/:id", async (req, res) => {
  const { id } = req.params;
  const initial = await getInitialData();
  const order = initial.orders.find((o) => o.id === id);
  if (!order) {
    return res.status(404).json({ error: "Not found" });
  }
  const enriched = withOrderItemImages(order, initial.products || []);
  res.json(enriched);
});

// Admin Routes

router.get("/admin/overview", requireAdmin, async (req, res) => {
  const { state } = req.adminContext;
  const orders = state.orders;
  const products = state.products;
  const messages = Array.isArray(state.messages) ? state.messages : [];
  const unreadByEmail = new Set(
    messages.filter((m) => !m.read && m.email).map((m) => m.email)
  );
  const overview = {
    totalProducts: products.length,
    totalOrders: orders.length,
    newOrders: orders.filter((o) => o.status === "processing").length,
    unreadMessages: unreadByEmail.size,
  };
  res.json(overview);
});

router.get("/admin/messages", requireAdmin, async (req, res) => {
  const { state } = req.adminContext;
  const messages = Array.isArray(state.messages)
    ? state.messages
        .slice()
        .sort((a, b) => {
          const aTime = new Date(a.createdAt).getTime();
          const bTime = new Date(b.createdAt).getTime();
          return bTime - aTime;
        })
    : [];
  res.json(messages);
});

router.get("/admin/subscribers", requireAdmin, async (req, res) => {
  const { state } = req.adminContext;
  const subscribers = Array.isArray(state.subscribers)
    ? state.subscribers
        .slice()
        .sort(
          (a, b) =>
            new Date(b.createdAt || 0).getTime() -
            new Date(a.createdAt || 0).getTime()
        )
    : [];
  res.json(subscribers);
});

router.post("/admin/messages/mark-read", requireAdmin, async (req, res) => {
  const { state } = req.adminContext;
  if (!Array.isArray(state.messages) || state.messages.length === 0) {
    return res.json({ success: true });
  }
  state.messages = state.messages.map((m) => ({
    ...m,
    read: true,
  }));
  await saveMessages(state.messages);
  res.json({ success: true });
});

router.delete("/admin/messages/:id", requireAdmin, async (req, res) => {
  const { id } = req.params;
  const { state } = req.adminContext;
  if (!Array.isArray(state.messages)) {
    state.messages = [];
  }
  const index = state.messages.findIndex((m) => m.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Not found" });
  }
  const removed = state.messages.splice(index, 1)[0];
  await saveMessages(state.messages);
  res.json(removed);
});

router.route("/admin/products")
  .get(requireAdmin, async (req, res) => {
    const { state } = req.adminContext;
    res.json(state.products);
  })
  .post(requireAdmin, async (req, res) => {
    try {
      const { state } = req.adminContext;
      const body = req.body;
      const id = createId();
      const product = {
        id,
        name: body.name || "",
        description: body.description || "",
        brand: body.brand || "ASSAIMART",
        size: body.size || "100ml",
        price: Number(body.price) || 0,
        originalPrice: body.originalPrice ? Number(body.originalPrice) : undefined,
        categorySlug: body.categorySlug || "premium",
        segment: body.segment || "unisex",
        tier: body.tier || "premium",
        productType: body.productType || "Perfume",
        featuredHome: Boolean(body.featuredHome),
        featuredMen: Boolean(body.featuredMen),
        featuredWomen: Boolean(body.featuredWomen),
        featuredUnisex: Boolean(body.featuredUnisex),
        imageUrl: body.imageUrl || "",
        notes: body.notes || "",
        available: body.available !== false,
        rating: body.rating !== undefined ? Number(body.rating) : undefined,
        ratingMedia: Array.isArray(body.ratingMedia) ? body.ratingMedia : [],
      };
      state.products.push(product);
      await saveProducts(state.products);
      res.status(201).json(product);
    } catch {
      res.status(400).json({ error: "Invalid request body" });
    }
  });

router.route("/admin/products/:id")
  .put(requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { state } = req.adminContext;
      const body = req.body;
      const index = state.products.findIndex((p) => p.id === id);
      if (index === -1) {
        return res.status(404).json({ error: "Not found" });
      }
      const existing = state.products[index];
      const updated = {
        ...existing,
        ...body,
        price: body.price !== undefined ? Number(body.price) : existing.price,
        originalPrice: body.originalPrice !== undefined ? Number(body.originalPrice) : existing.originalPrice,
        rating: body.rating !== undefined ? Number(body.rating) : existing.rating,
        ratingMedia: body.ratingMedia !== undefined
          ? (Array.isArray(body.ratingMedia) ? body.ratingMedia : existing.ratingMedia)
          : existing.ratingMedia,
      };
      state.products[index] = updated;
      await saveProducts(state.products);
      res.json(updated);
    } catch {
      res.status(400).json({ error: "Invalid request body" });
    }
  })
  .delete(requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { state } = req.adminContext;
    const index = state.products.findIndex((p) => p.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Not found" });
    }
    const removed = state.products.splice(index, 1)[0];
    await saveProducts(state.products);
    res.json(removed);
  });

router.get("/admin/orders", requireAdmin, async (req, res) => {
  const { state } = req.adminContext;
  const orders = Array.isArray(state.orders)
    ? state.orders.map((order) => withOrderItemImages(order, state.products || []))
    : [];
  res.json(orders);
});

router.route("/admin/orders/:id")
  .get(requireAdmin, async (req, res) => {
    const { id } = req.params;
    const initial = await getInitialData();
    const order = initial.orders.find((o) => o.id === id);
    if (!order) {
      return res.status(404).json({ error: "Not found" });
    }
    const enriched = withOrderItemImages(order, initial.products || []);
    res.json(enriched);
  })
  .put(requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { state } = req.adminContext;
      const body = req.body;
      const index = state.orders.findIndex((o) => o.id === id);
      if (index === -1) {
        return res.status(404).json({ error: "Not found" });
      }
      const existing = state.orders[index];
      const updated = {
        ...existing,
        ...body,
      };
      state.orders[index] = updated;
      await saveOrders(state.orders);
      res.json(updated);
    } catch {
      res.status(400).json({ error: "Invalid request body" });
    }
  })
  .delete(requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { state } = req.adminContext;
    const index = state.orders.findIndex((o) => o.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Not found" });
    }
    const removed = state.orders.splice(index, 1)[0];
    await saveOrders(state.orders);
    res.json(removed);
  });

export default router;
